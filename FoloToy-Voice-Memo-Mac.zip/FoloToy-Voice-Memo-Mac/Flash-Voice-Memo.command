#!/bin/bash
set -euo pipefail
trap 'result=$?; if [ "$result" -ne 0 ]; then echo "操作未完成，请将上方输出发回聊天。"; fi; echo "按回车关闭窗口"; read -r || true' EXIT
cd -- "$(dirname -- "$0")"
flash_python="$HOME/folotoy-flash-env/bin/python"
if [ ! -x "$flash_python" ]; then
    echo "找不到之前建立的 folotoy-flash-env，未刷写。"
    exit 1
fi
"$flash_python" -c 'import importlib.metadata; assert importlib.metadata.version("esptool") == "4.12.0", "需要 esptool 4.12.0，未刷写"'
"$flash_python" flash_memo.py
