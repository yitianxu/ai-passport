from pathlib import Path
import hashlib
import re
import subprocess
import sys

PORT = '/dev/cu.usbmodem14301'
IMAGE_SHA256 = 'f435734c800b0b51bef047f3fc15f2c6fe8813d75e617e8ef72a1e7f6ed56388'

def matches_device(output):
    return (re.search(r'^Chip is ESP32-C3\b', output, re.M) is not None
            and re.search(r'^Detected flash size: 8MB\s*$', output, re.M) is not None
)

def main():
    image = Path(__file__).resolve().parent / 'FoloToy-AI-Passport-full.bin'
    if hashlib.sha256(image.read_bytes()).hexdigest() != IMAGE_SHA256:
        raise SystemExit('固件校验失败，未刷写。请重新下载完整安装包。')
    if not Path(PORT).exists():
        raise SystemExit(f'串口 {PORT} 不存在，未刷写。请连接设备并把提示发回聊天。')
    command = [sys.executable, '-m', 'esptool', '--chip', 'esp32c3', '--port', PORT]
    print('固件哈希正确。识别设备（会复位，不写入 Flash）……', flush=True)
    found = subprocess.run(command + ['flash_id'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    print(found.stdout, flush=True)
    if found.returncode or not matches_device(found.stdout):
        raise SystemExit('设备身份、芯片或容量不匹配，未刷写。请把提示发回聊天。')
    print('目标设备匹配。按已授权的不保留旧数据方式刷写；不执行整片擦除。', flush=True)
    subprocess.run(command + ['--baud', '460800', 'write_flash', '--flash_mode', 'dio', '--flash_freq', '80m', '--flash_size', '8MB', '0x0', str(image)], check=True)
    print('\n刷写成功。请检查 VOICE / POCKET 界面并测试录音回放。')

if __name__ == '__main__':
    main()
